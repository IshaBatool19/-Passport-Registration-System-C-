# Passport Management System (C++)

A simple console-based Passport Registration & Management system demonstrating
multi-level inheritance, friend functions, and file I/O in C++.

## Class Hierarchy
- `passport` — base class: registration, fee calculation, viewing records
- `login_details` (protected inheritance from `passport`) — login, change/forgot password
- `sideinfo` (protected inheritance from `login_details`) — expiry check, `display()` friend function

## Files
- `passport.h`      — class declarations (header)
- `passport.cpp`    — implementation of all member functions
- `main.cpp`        — menu-driven driver program
- `README.md`       — this file

## Build

```bash
g++ -std=c++17 -Wall -o passport_system main.cpp passport.cpp
```

## Run

```bash
./passport_system
```

## Notes
- Registered records are appended to `passport_records.txt` when you run the program.
- Passport IDs are auto-generated (starting at 1000).
- Fee is calculated based on age: under 18 = 1500, 18–60 = 3000, over 60 = 2000.
- Expiry date is mocked as issue date + 10 years, based on the system clock.
