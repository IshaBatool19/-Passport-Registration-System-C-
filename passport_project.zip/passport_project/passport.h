#pragma once
#include <iostream>  // basic input output library
#include <iomanip>   // input output manipulations
#include <cstdlib>   // for Srand or Rand
#include <string>    // for string
#include <ctime>     // for time(NULL)
#include <cctype>    // for isalpha and isspace
#include <fstream>   // for file handling
using namespace std;
const int max_count = 100; // const variable initialize
class passport
{
protected:
    // data members
    int count = 0;
    string first_name[max_count]; // array to store records
    string last_name[max_count];
    string email[max_count];
    string CNIC[max_count];
    long int ph_no[max_count];
    string pasword[max_count];
    int age[max_count];
    char gender[max_count];
    int id[max_count];
    double fee;
    string nationality[max_count];
public:
    // member functions
    void passport_registation(fstream& outputfile); // function to register account
    void userfee_details();
    void view_details(); // display list 
};
class login_details : protected passport
{
public:
    // Member Functions
    void login();
    void change_pasword();
    void forget_pasword();
};
void display();
class sideinfo : protected login_details
{
public:
    void expiry();
    friend void display(); // declare as a friend function
};
