#include "passport.h"

// sideinfo inherits (protected) from login_details which inherits
// (protected) from passport, so a single sideinfo object gives us
// access to every feature in the system through its public methods.
class system_manager : public sideinfo
{
public:
    void registration_menu(fstream& outputfile) { passport_registation(outputfile); }
    void fee_menu()      { userfee_details(); }
    void view_menu()     { view_details(); }
    void login_menu()    { login(); }
    void change_pw_menu(){ change_pasword(); }
    void forgot_pw_menu(){ forget_pasword(); }
    void expiry_menu()   { expiry(); }
};

static void print_menu()
{
    cout << "\n----------------- MAIN MENU -----------------\n";
    cout << "1. Register New Passport Applicant\n";
    cout << "2. Login\n";
    cout << "3. View Fee Details\n";
    cout << "4. View All Registered Applicants\n";
    cout << "5. Change Password\n";
    cout << "6. Forgot Password\n";
    cout << "7. Check Passport Expiry\n";
    cout << "0. Exit\n";
    cout << "----------------------------------------------\n";
    cout << "Enter your choice: ";
}

int main()
{
    srand((unsigned int)time(nullptr));

    system_manager sys;
    fstream outputfile("passport_records.txt", ios::app);

    display(); // friend function banner

    int choice = -1;
    do
    {
        print_menu();
        cin >> choice;

        switch (choice)
        {
        case 1: sys.registration_menu(outputfile); break;
        case 2: sys.login_menu();                  break;
        case 3: sys.fee_menu();                    break;
        case 4: sys.view_menu();                   break;
        case 5: sys.change_pw_menu();              break;
        case 6: sys.forgot_pw_menu();              break;
        case 7: sys.expiry_menu();                 break;
        case 0: cout << "\nExiting... Goodbye!\n"; break;
        default: cout << "\nInvalid choice, try again.\n"; break;
        }

    } while (choice != 0);

    outputfile.close();
    return 0;
}
