#include "passport.h"

// ---------------------------------------------------------
// Helper: validate that a string contains only alphabetic
// characters and spaces (used for names / nationality)
// ---------------------------------------------------------
static bool isValidName(const string& s)
{
    if (s.empty())
        return false;
    for (char c : s)
    {
        if (!isalpha((unsigned char)c) && !isspace((unsigned char)c))
            return false;
    }
    return true;
}

// ---------------------------------------------------------
// passport::passport_registation
// Registers a new passport applicant, stores the record in
// memory arrays, and writes a copy to the given output file.
// ---------------------------------------------------------
void passport::passport_registation(fstream& outputfile)
{
    if (count >= max_count)
    {
        cout << "\nRecord limit reached. Cannot register more applicants.\n";
        return;
    }

    int i = count;
    cout << "\n----- Passport Registration -----\n";

    cout << "Enter First Name: ";
    cin >> first_name[i];

    cout << "Enter Last Name: ";
    cin >> last_name[i];

    cout << "Enter Email: ";
    cin >> email[i];

    cout << "Enter CNIC (xxxxx-xxxxxxx-x): ";
    cin >> CNIC[i];

    cout << "Enter Phone Number: ";
    cin >> ph_no[i];

    cout << "Enter Password: ";
    cin >> pasword[i];

    cout << "Enter Age: ";
    cin >> age[i];

    cout << "Enter Gender (M/F): ";
    cin >> gender[i];

    cout << "Enter Nationality: ";
    cin >> nationality[i];

    // Simple auto-generated ID: 1000 + running count
    id[i] = 1000 + i;

    count++;

    // Persist the record to file
    if (outputfile)
    {
        outputfile << "ID: " << id[i]
                   << " | Name: " << first_name[i] << " " << last_name[i]
                   << " | Email: " << email[i]
                   << " | CNIC: " << CNIC[i]
                   << " | Phone: " << ph_no[i]
                   << " | Age: " << age[i]
                   << " | Gender: " << gender[i]
                   << " | Nationality: " << nationality[i]
                   << "\n";
    }

    cout << "\nRegistration successful! Your Passport ID is: " << id[i] << "\n";
}

// ---------------------------------------------------------
// passport::userfee_details
// Calculates and displays the passport fee based on age.
// ---------------------------------------------------------
void passport::userfee_details()
{
    if (count == 0)
    {
        cout << "\nNo records available. Please register first.\n";
        return;
    }

    int idx = count - 1; // most recently registered applicant
    double base_fee = 0.0;

    if (age[idx] < 18)
        base_fee = 1500.0;
    else if (age[idx] <= 60)
        base_fee = 3000.0;
    else
        base_fee = 2000.0; // senior citizen discount

    fee = base_fee;

    cout << "\n----- Fee Details -----\n";
    cout << "Applicant : " << first_name[idx] << " " << last_name[idx] << "\n";
    cout << "Age       : " << age[idx] << "\n";
    cout << fixed << setprecision(2);
    cout << "Fee Due   : Rs. " << fee << "\n";
}

// ---------------------------------------------------------
// passport::view_details
// Displays all registered passport applicants in a table.
// ---------------------------------------------------------
void passport::view_details()
{
    if (count == 0)
    {
        cout << "\nNo records to display.\n";
        return;
    }

    cout << "\n----- All Registered Applicants -----\n";
    cout << left
         << setw(6)  << "ID"
         << setw(15) << "First Name"
         << setw(15) << "Last Name"
         << setw(6)  << "Age"
         << setw(8)  << "Gender"
         << setw(15) << "Nationality"
         << setw(15) << "Phone"
         << "\n";
    cout << string(80, '-') << "\n";

    for (int i = 0; i < count; i++)
    {
        cout << left
             << setw(6)  << id[i]
             << setw(15) << first_name[i]
             << setw(15) << last_name[i]
             << setw(6)  << age[i]
             << setw(8)  << gender[i]
             << setw(15) << nationality[i]
             << setw(15) << ph_no[i]
             << "\n";
    }
}

// ===========================================================
// login_details member functions
// ===========================================================

// ---------------------------------------------------------
// login_details::login
// Checks entered credentials (email + password) against the
// records stored in the protected base-class arrays.
// ---------------------------------------------------------
void login_details::login()
{
    if (count == 0)
    {
        cout << "\nNo registered users yet. Please register first.\n";
        return;
    }

    string in_email, in_password;
    cout << "\n----- Login -----\n";
    cout << "Email: ";
    cin >> in_email;
    cout << "Password: ";
    cin >> in_password;

    for (int i = 0; i < count; i++)
    {
        if (email[i] == in_email && pasword[i] == in_password)
        {
            cout << "\nLogin successful! Welcome, " << first_name[i] << ".\n";
            return;
        }
    }

    cout << "\nInvalid email or password.\n";
}

// ---------------------------------------------------------
// login_details::change_pasword
// Lets a logged-in style user change their password after
// verifying the old one.
// ---------------------------------------------------------
void login_details::change_pasword()
{
    if (count == 0)
    {
        cout << "\nNo registered users yet.\n";
        return;
    }

    string in_email, old_password, new_password;
    cout << "\n----- Change Password -----\n";
    cout << "Email: ";
    cin >> in_email;

    for (int i = 0; i < count; i++)
    {
        if (email[i] == in_email)
        {
            cout << "Current Password: ";
            cin >> old_password;

            if (pasword[i] != old_password)
            {
                cout << "\nIncorrect current password.\n";
                return;
            }

            cout << "New Password: ";
            cin >> new_password;
            pasword[i] = new_password;

            cout << "\nPassword changed successfully.\n";
            return;
        }
    }

    cout << "\nNo account found with that email.\n";
}

// ---------------------------------------------------------
// login_details::forget_pasword
// Simple recovery flow: verifies email + CNIC, then allows
// the user to set a new password.
// ---------------------------------------------------------
void login_details::forget_pasword()
{
    if (count == 0)
    {
        cout << "\nNo registered users yet.\n";
        return;
    }

    string in_email, in_cnic, new_password;
    cout << "\n----- Forgot Password -----\n";
    cout << "Registered Email: ";
    cin >> in_email;
    cout << "CNIC (for verification): ";
    cin >> in_cnic;

    for (int i = 0; i < count; i++)
    {
        if (email[i] == in_email && CNIC[i] == in_cnic)
        {
            cout << "Identity verified. Enter New Password: ";
            cin >> new_password;
            pasword[i] = new_password;

            cout << "\nPassword reset successfully.\n";
            return;
        }
    }

    cout << "\nVerification failed. Email/CNIC do not match our records.\n";
}

// ===========================================================
// sideinfo member function + friend function
// ===========================================================

// ---------------------------------------------------------
// sideinfo::expiry
// Calculates a mock passport expiry date (issue date + 10
// years) using the current system time.
// ---------------------------------------------------------
void sideinfo::expiry()
{
    time_t now = time(nullptr);
    tm* local_time = localtime(&now);

    int issue_year  = local_time->tm_year + 1900;
    int issue_month = local_time->tm_mon + 1;
    int issue_day   = local_time->tm_mday;

    int expiry_year = issue_year + 10; // passports valid for 10 years

    cout << "\n----- Passport Validity -----\n";
    cout << "Issue Date  : " << issue_day << "/" << issue_month << "/" << issue_year << "\n";
    cout << "Expiry Date : " << issue_day << "/" << issue_month << "/" << expiry_year << "\n";
}

// ---------------------------------------------------------
// Global friend function: display
// Shown as a friend of sideinfo; prints a simple banner.
// (Kept free-standing since it only needs public info here.)
// ---------------------------------------------------------
void display()
{
    cout << "\n=========================================\n";
    cout << "     NATIONAL PASSPORT MANAGEMENT SYSTEM   \n";
    cout << "=========================================\n";
}
